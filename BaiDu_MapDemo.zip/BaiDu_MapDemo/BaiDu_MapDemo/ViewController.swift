//
//  ViewController.swift
//  BaiDu_MapDemo
//
//  Created by Alok  on 7/5/16.
//  Copyright © 2016 alok. All rights reserved.
//

import UIKit

class ViewController: UIViewController,BMKMapViewDelegate {

    var _mapView: BMKMapView?
    var pointAnnotation: BMKPointAnnotation?
    var animatedAnnotation: BMKPointAnnotation?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.loadMap()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        BMKMapView.enableCustomMapStyle(false)
        _mapView?.viewWillAppear()
        _mapView?.delegate = self
        
        self.addPointAnnotation()
        self.addAnimatedAnnotation()
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        BMKMapView.enableCustomMapStyle(false)//消失时，关闭个性化地图
        _mapView?.viewWillDisappear()
        _mapView?.delegate = nil
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //MARK: MapView Methods
    func loadMap(){
        _mapView = BMKMapView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height))
        self.view.addSubview(_mapView!)
        
        addCustomGesture()
    }
    
    
    // MARK: - BMKMapViewDelegate
    
    func mapViewDidFinishLoading(mapView: BMKMapView!) {
        let alertVC = UIAlertController(title: "", message: "BMKMapView控件初始化完成", preferredStyle: .Alert)
        let alertAction = UIAlertAction(title: "知道了", style: .Cancel, handler: nil)
        alertVC.addAction(alertAction)
        self .presentViewController(alertVC, animated: true, completion: nil)
    }

    // MARK: - Add custom gestures (if custom gesture, without following code）
    func addCustomGesture() {
        /*
         *note：
         *Adding custom gestures, you must set the cancelsTouchesInView UIGestureRecognizer and delaysTouchesEnded property is set to false, or affect the internal map of gesture processing
         */
        let tapGesturee = UITapGestureRecognizer(target: self, action: #selector(ViewController.handleSingleTap(_:)))
        tapGesturee.cancelsTouchesInView = false
        tapGesturee.delaysTouchesEnded = false
        self.view.addGestureRecognizer(tapGesturee)
    }
    
    func handleSingleTap(tap: UITapGestureRecognizer) {
        NSLog("custom single tap handle")
    }
// MARK: Annnotation Pin
    //Adding Dimensions
    func addPointAnnotation() {
        if pointAnnotation == nil {
            pointAnnotation = BMKPointAnnotation()
            pointAnnotation?.coordinate = CLLocationCoordinate2DMake(39.915, 116.404)
            pointAnnotation?.title = "I'm pointAnnotation"
            pointAnnotation?.subtitle = "This Annotation Can drag!"
        }
        _mapView!.addAnnotation(pointAnnotation)
    }
    
    // Add animation Annotation
    func addAnimatedAnnotation() {
        if animatedAnnotation == nil {
            animatedAnnotation = BMKPointAnnotation()
            animatedAnnotation?.coordinate = CLLocationCoordinate2DMake(40.115, 116.404)
            animatedAnnotation?.title = "Add animation Annotation"
        }
        _mapView!.addAnnotation(animatedAnnotation)
    }
    func mapView(mapView: BMKMapView!, viewForAnnotation annotation: BMKAnnotation!) -> BMKAnnotationView! {
        // 普通标注
        if (annotation as! BMKPointAnnotation) == pointAnnotation {
            let AnnotationViewID = "renameMark"
            var annotationView = mapView.dequeueReusableAnnotationViewWithIdentifier(AnnotationViewID) as! BMKPinAnnotationView?
            if annotationView == nil {
                annotationView = BMKPinAnnotationView(annotation: annotation, reuseIdentifier: AnnotationViewID)
                // 设置颜色
                annotationView!.pinColor = UInt(BMKPinAnnotationColorPurple)
                // 从天上掉下的动画
                annotationView!.animatesDrop = true
                // 设置可拖曳
                annotationView!.draggable = true
            }
            annotationView?.annotation = annotation
            return annotationView
        }
        
        // 动画标注
        if (annotation as! BMKPointAnnotation) == animatedAnnotation {
            let AnnotationViewID = "AnimatedAnnotation"
            let annotationView = AnimatedAnnotationView(annotation: annotation, reuseIdentifier: AnnotationViewID)
            
            var images = Array(count: 3, repeatedValue: UIImage())
            for i in 1...3 {
                let image = UIImage(named: "poi_\(i).png")
                images[i-1] = image!
            }
            annotationView.setImages(images)
            return annotationView
        }
        return nil
    }

}

