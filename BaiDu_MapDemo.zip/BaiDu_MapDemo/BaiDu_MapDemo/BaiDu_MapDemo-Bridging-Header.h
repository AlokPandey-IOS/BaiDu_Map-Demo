//
//  BaiDu_MapDemo-Bridging-Header.h
//  BaiDu_MapDemo
//
//  Created by Alok  on 7/5/16.
//  Copyright © 2016 alok. All rights reserved.
//

#ifndef BaiDu_MapDemo_Bridging_Header_h
#define BaiDu_MapDemo_Bridging_Header_h
#import <BaiduMapAPI_Base/BMKBaseComponent.h>
#import <BaiduMapAPI_Map/BMKMapComponent.h>
#import <BaiduMapAPI_Location/BMKLocationComponent.h>
#import <BaiduMapAPI_Cloud/BMKCloudSearchComponent.h>
#import <BaiduMapAPI_Radar/BMKRadarComponent.h>
#import <BaiduMapAPI_Search/BMKSearchComponent.h>
#import <BaiduMapAPI_Utils/BMKUtilsComponent.h>

//#import "BMKClusterManager.h"
//#import "PromptInfo.h"

#endif /* BaiDu_MapDemo_Bridging_Header_h */
